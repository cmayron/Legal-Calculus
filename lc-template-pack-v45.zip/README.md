# Legal Calculus Template Pack (v4.5)

This pack mirrors the quickstart checklist. Start here:
- `element-proof-table.csv`
- `procedural-deadline-grid.csv`
- `exhibit-index.csv`
Then pick a filing skeleton (complaint or TRO/PI) and add a `certificate-of-service.md` and `proposed-order-template.md`.

**Note**: Educational scaffolding only. Verify local rules and formatting.
