# Certificate of Service (Template)

I certify that on [date], I served the foregoing [document name] on the following by [method] at [address/email/fax], and filed the same with the Court:

- [Name], [Role], [Address/Email]

Dated: ____________          ______________________________  
[Your Name]
