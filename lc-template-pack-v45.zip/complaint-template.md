# Complaint Template (Skeleton)

> Replace bracketed text. Keep headings; they help your structure.

**Caption**  
[COURT NAME]  
[Plaintiff] v. [Defendant(s)]  
Case No.: [To be assigned]

## I. Parties, Jurisdiction, Venue
- Parties: [Identify]
- Jurisdiction: [Statutes/Constitution; amount‑in‑controversy if applicable]
- Venue: [Why proper]

## II. Introduction & Relief Sought
- One paragraph summary of dispute and tailored relief requested.

## III. Facts
- Chronological, numbered paragraphs with cites to exhibits (Ex. A, ¶2).

## IV. Claims for Relief
For each claim:
- **Claim Name & Authority** (e.g., 42 U.S.C. § 1983 – First Amendment Retaliation)
- **Elements**: list each element
- **Application**: tie facts + exhibits to each element (see element/Proof Table)

## V. Prayer for Relief
- Declaratory relief: […]
- Injunctive relief: […]
- Damages (if applicable): […]
- Fees/costs: […]
- Other: […]
- **Proposed order** attached.

## VI. Jury Demand (if applicable)

## VII. Signature
[Name, Address, Email, Phone, Signature block]

---

### Certificate of Service
(Attach `certificate-of-service.md`)

### Exhibit List
(Attach `exhibit-index.csv` and stamp exhibits A, B, C…)
