# Hearing Kit — Openings & Anchors

## 30‑Second Opening
- Who you are, what you need today, the rule/standard, and where the record proves it.

## 60‑Second Opening
- Add 1–2 strongest record cites. Tie each to a required element.

## 90‑Second Opening
- Add equities/public interest. End with a focused, tailored ask.

## Anchors (Examples)
- “Element 2 is satisfied at Ex. B, ¶7.”
- “Relief is narrowly drawn to stop X for Y days pending hearing.”
- “Appeal‑preservation: objection at Dkt. 14, p. 3.”
