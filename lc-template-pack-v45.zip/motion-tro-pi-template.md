# Motion for Temporary Restraining Order / Preliminary Injunction (Skeleton)

**Caption**  
[COURT NAME] — [Plaintiff] v. [Defendant(s)] — Case No. [__]

## Introduction
One paragraph: what you seek, why immediate relief is necessary.

## Background Facts
Short, record‑cited summary pointing to exhibits and declarations.

## Legal Standard
Cite your circuit’s TRO/PI standard (e.g., *Winter* factors).

## Argument (Four Factors)
1. **Likelihood of Success** — element mapping with cites (Ex. A–C).  
2. **Irreparable Harm** — declarations; why money damages won’t fix.  
3. **Balance of Equities** — hardship comparison; narrow tailoring.  
4. **Public Interest** — statutes/policies; patient/public safety; compliance.

## Scope & Tailoring
- Precisely define the prohibited/required conduct.  
- **Bond** proposal (or grounds for none).

## Proposed Order
Attach `proposed-order-template.md` with tailored relief.

## Certificate of Service
Attach `certificate-of-service.md`.
