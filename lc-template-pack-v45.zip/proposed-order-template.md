# Proposed Order (Template)

The Court, having considered Plaintiff’s Motion [ECF __], **ORDERS**:

1. [Specific injunctive term #1].
2. [Specific injunctive term #2].
3. [Duration / conditions].
4. Bond: [amount / waived with reasons].

IT IS SO ORDERED.

Dated: ____________          ______________________________  
                            United States [District/State] Judge
